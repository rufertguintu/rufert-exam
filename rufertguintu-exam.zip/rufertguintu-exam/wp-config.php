<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'rufert-exam' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '{v$-,!k`)qW9DmhE(_*^ro-R9(7HL!Jy+KRq[Ks@i>F7Mvv?N>X=B3V2s7r)/Dtp' );
define( 'SECURE_AUTH_KEY',  '#>q:aX|$~qJpucB&a$|6K8 V`sde;M?+Q.+X*,G1?2aK-YOHnI&P.lWT-C6a`5sB' );
define( 'LOGGED_IN_KEY',    'd`u5I,Z7{OgO!4Yt>p %f6F,J12W~JBP6R2:rvp^Nii@Tbe 68u%&|9,v8B9@,.j' );
define( 'NONCE_KEY',        'Hcm~P*h%4U&92j^t]LY*WE2?d,p(er!pe>lf91}3JmCU#;)*4M]7 HdA}n3UhmAr' );
define( 'AUTH_SALT',        '`hvd`G.A!x`-X >=1UBI2df{%ircZtHqEVX>_J#*FC_5sZ|R<5upHDARRD)Smr4J' );
define( 'SECURE_AUTH_SALT', 'Lwd6|fB4*wK9VDZH-DYW{TjI6Bnb63o#>LHQ#Da^0oa*4m@{IS%c:E$v%}B:vgi*' );
define( 'LOGGED_IN_SALT',   '#(6|E5;MKA1{.j.l<xEJMHt:|^vmMJ^5hG~javgEc)Pzf]}IRR=Ud.I.wr^I@3o;' );
define( 'NONCE_SALT',       ';?YVXL!@G3Q<&aE&E4R.UxgJK=UrG!O(n47Szh}yE,r@^O)Mh+/2]L{1oGC:T4vp' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
